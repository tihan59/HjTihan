import React, { useEffect, useRef, useState } from 'react';

const About: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  const skills = [
    { name: 'Product Management', level: 95, color: 'from-blue-400 to-blue-600' },
    { name: 'Flutter & Dart', level: 75, color: 'from-cyan-400 to-cyan-600' },
    { name: 'Next.js & React', level: 70, color: 'from-green-400 to-green-600' },
    { name: 'Firebase', level: 80, color: 'from-orange-400 to-orange-600' },
    { name: 'UI/UX Strategy', level: 88, color: 'from-purple-400 to-purple-600' },
    { name: 'Team Leadership', level: 92, color: 'from-pink-400 to-pink-600' },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" ref={sectionRef} className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-800/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
              About Me
            </span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-cyan-400 to-purple-500 mx-auto"></div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Bio Section */}
          <div className={`space-y-6 ${isVisible ? 'animate-fade-in-left' : 'opacity-0'}`}>
            <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50">
              <h3 className="text-2xl font-bold text-cyan-400 mb-4">Who I Am</h3>
              <p className="text-gray-300 leading-relaxed mb-4">
                I am Horram Jawad Tihan, a passionate and experienced Product Manager with over 3 years of leading successful digital projects. Recently, I have begun expanding my skills into software development, focusing on Flutter, Dart, and modern web technologies like Next.js and Firebase.
              </p>
              <p className="text-gray-300 leading-relaxed mb-4">
                My background in product strategy and team leadership gives me a unique perspective on software development, helping me create user-centric, high-quality products. I am committed to continuous learning and bridging the gap between product vision and technical execution.
              </p>
              <p className="text-gray-300 leading-relaxed">
                I believe that combining strong product management with hands-on development skills is key to delivering innovative and impactful digital experiences.
              </p>
            </div>

            <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50">
              <h3 className="text-2xl font-bold text-purple-400 mb-4">Personal Vision</h3>
              <blockquote className="text-gray-300 italic text-lg">
                "To grow as a versatile technology leader who builds meaningful products by blending management insight with development skills."
              </blockquote>
            </div>
          </div>

          {/* Skills Section */}
          <div className={`${isVisible ? 'animate-fade-in-right' : 'opacity-0'}`}>
            <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50">
              <h3 className="text-2xl font-bold text-cyan-400 mb-8">Skills & Expertise</h3>
              <div className="space-y-6">
                {skills.map((skill, index) => (
                  <div key={skill.name} className="group">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-white font-medium">{skill.name}</span>
                      <span className="text-gray-400">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-3 overflow-hidden">
                      <div
                        className={`h-full bg-gradient-to-r ${skill.color} rounded-full transition-all duration-1000 ease-out transform origin-left ${
                          isVisible ? 'scale-x-100' : 'scale-x-0'
                        }`}
                        style={{
                          width: `${skill.level}%`,
                          transitionDelay: `${index * 200}ms`
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50 text-center">
                <div className="text-3xl font-bold text-cyan-400 mb-2">3+</div>
                <div className="text-gray-300">Years in Product Management</div>
              </div>
              <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50 text-center">
                <div className="text-3xl font-bold text-purple-400 mb-2">15+</div>
                <div className="text-gray-300">Projects Led</div>
              </div>
            </div>

            <div className="mt-4 bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50">
              <h4 className="text-lg font-bold text-white mb-3">Key Strengths</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="text-gray-300">• Product Strategy & Execution</div>
                <div className="text-gray-300">• Team Leadership</div>
                <div className="text-gray-300">• Flutter Development</div>
                <div className="text-gray-300">• Problem-solving</div>
                <div className="text-gray-300">• User-centric Design</div>
                <div className="text-gray-300">• Visionary Mindset</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
