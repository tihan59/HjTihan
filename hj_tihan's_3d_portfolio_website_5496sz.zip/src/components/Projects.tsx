import React, { useEffect, useRef, useState } from 'react';

const Projects: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  const projects = [
    {
      title: 'FaizoWorld',
      description: 'OTP-based real-time chat application similar to WhatsApp with end-to-end encryption, media sharing, and group chat functionality.',
      techStack: ['Flutter', 'Firebase', 'Dart', 'Real-time Database'],
      liveUrl: '#',
      githubUrl: '#',
      imageUrl: '/api/placeholder/400/250',
      featured: true,
    },
    {
      title: 'FaTi Warzone',
      description: 'High-graphics 3D offline mobile shooting game with advanced physics, multiple game modes, and immersive gameplay experience.',
      techStack: ['Unity', 'C#', '3D Graphics', 'Mobile Optimization'],
      liveUrl: '#',
      githubUrl: '#',
      imageUrl: '/api/placeholder/400/250',
      featured: true,
    },
    {
      title: 'Probashi Enterprise',
      description: 'Comprehensive product import/export website with inventory management, order tracking, and multi-language support.',
      techStack: ['Next.js', 'Firebase', 'Tailwind CSS', 'TypeScript'],
      liveUrl: '#',
      githubUrl: '#',
      imageUrl: '/api/placeholder/400/250',
      featured: true,
    },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="projects" ref={sectionRef} className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
              Featured Projects
            </span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-cyan-400 to-purple-500 mx-auto mb-6"></div>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Showcasing innovative solutions that blend creativity with cutting-edge technology
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div
              key={project.title}
              className={`group relative bg-gray-900/50 backdrop-blur-sm rounded-2xl overflow-hidden border border-gray-700/50 hover:border-cyan-400/50 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/10 ${
                isVisible ? 'animate-fade-in-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${index * 200}ms` }}
            >
              {/* Project Image */}
              <div className="relative h-48 bg-gradient-to-br from-cyan-500/20 to-purple-500/20 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent z-10"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-6xl opacity-20">
                    {project.title === 'FaizoWorld' && '💬'}
                    {project.title === 'FaTi Warzone' && '🎮'}
                    {project.title === 'Probashi Enterprise' && '🏢'}
                  </div>
                </div>
              </div>

              {/* Project Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-cyan-400 transition-colors">
                  {project.title}
                </h3>
                <p className="text-gray-400 text-sm mb-4 leading-relaxed">
                  {project.description}
                </p>

                {/* Tech Stack */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.techStack.map((tech) => (
                    <span
                      key={tech}
                      className="px-3 py-1 bg-gray-800/50 text-cyan-400 text-xs rounded-full border border-cyan-400/20"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <a
                    href={project.liveUrl}
                    className="flex-1 bg-gradient-to-r from-cyan-500 to-purple-600 text-white py-2 px-4 rounded-lg text-sm font-medium text-center hover:from-cyan-600 hover:to-purple-700 transition-all duration-300"
                  >
                    Live Demo
                  </a>
                  <a
                    href={project.githubUrl}
                    className="flex-1 border border-gray-600 text-gray-300 py-2 px-4 rounded-lg text-sm font-medium text-center hover:border-cyan-400 hover:text-cyan-400 transition-all duration-300"
                  >
                    GitHub
                  </a>
                </div>
              </div>

              {/* Hover Effect Overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
            </div>
          ))}
        </div>

        {/* View More Button */}
        <div className="text-center mt-12">
          <button className="group relative px-8 py-4 bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-full text-gray-300 font-semibold hover:border-cyan-400/50 hover:text-cyan-400 transition-all duration-300">
            <span className="relative z-10">View All Projects</span>
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </button>
        </div>
      </div>
    </section>
  );
};

export default Projects;
